# LLM Agent Toolkit

A hands-on project building up to a working **tool-calling AI agent** that runs a local Qwen model, decides what the user wants, and routes the request to the right tool.

## The Agent (`Task 2 AI Agent.ipynb`)

The main notebook. It takes a natural-language request and:

1. **Decides intent** — the LLM returns structured JSON (validated with Pydantic) choosing one of: schedule management, location info, simple analytics, or a general response.
2. **Calls the right tool:**
   - **Schedule management** — create, update, reschedule, and delete events in an in-memory calendar
   - **Location info** — country, timezone, and current local time for a set of cities
   - **Simple analytics** — average, min, max, and count over a list of numbers
3. **Writes a final answer** — the LLM turns the raw tool result into a clear reply.

It also has a **rule-based fallback** so it still works if the model returns bad JSON.

## Building-Block Notebooks

- **Calling LLM** — load and run a local Qwen model with Hugging Face Transformers; a simple summarization demo
- **Task 1 Output Parser** — extract structured candidate info as validated JSON using LangChain + Groq + Pydantic
- **CandidateInfo** — the same extraction idea done fully locally with Qwen and manual JSON validation

## Setup

```bash
pip install -r requirements.txt
```

The Task 1 notebook uses Groq — add your API key where indicated (free key at https://console.groq.com/keys):

```python
os.environ["GROQ_API_KEY"] = "YOUR_API_KEY"
```

The other notebooks run fully offline on a local Qwen model. Open any notebook and run it top to bottom.

## Tech Stack

Python · Hugging Face Transformers · Qwen2 / Qwen2.5 · PyTorch · Pydantic · LangChain · Groq
